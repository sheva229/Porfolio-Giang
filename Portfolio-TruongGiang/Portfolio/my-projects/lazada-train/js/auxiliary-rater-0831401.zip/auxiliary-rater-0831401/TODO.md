Things to do and ideas
---

- ~~Ajax post when rating done~~
- ~~readonly status~~
- ~~Callback function~~
- ~~Set number of stars, initial value~~
- ~~Set glyphs~~
- ~~Prevent multiple instantiations~~
- ~~Set extra data and send (like id)~~
- ~~Easy rate get/set~~
- ~~Set dynamic value for the stars (3 and 1/3 of stars full) when showing poll results~~
- ~~Flexible options for different images, glyphs, svg, ...~~
- ~~Tooltip support~~
- ~~Use trigger and call an event when it's about to change~~
- ~~options pattern~~
- ~~remove method~~
- ~~extra optional layer for faces, ...~~
- ~~low priority: plus, minus buttons for adding, subtracting values. Also keyboard support would be nice.~~
- ~~Add support for symbol per element index~~
